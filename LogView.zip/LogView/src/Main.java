import java.util.ArrayList;


public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Repo repo = Repo.getDBUtilsInstace();
		repo.connect();
		
		ArrayList<String> logs = repo.listAllLogs();
		
		for(String log : logs) {
			System.out.println(log);
		}
		
		repo.disconnect();
	}

}
