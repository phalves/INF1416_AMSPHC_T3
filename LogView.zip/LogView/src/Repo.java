

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class Repo {
	private static Repo instance = null;

	public static Repo getDBUtilsInstace() {
		if (instance == null) {
			instance = new Repo();
		}

		return instance;
	}

	private Repo() {}

	private static final String mdbFile = "C:\\Users\\Paulo\\workspace\\t3\\T1_Seg_20132.mdb";
	private Connection connection;

	public void connect() {
		Connection connection = null;

		try {
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			String connectionString = "jdbc:odbc:Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=" + mdbFile + ";";
			connection = DriverManager.getConnection(connectionString, "", "");

			this.connection = connection;
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Couldn't stablish connection to " + mdbFile);
		}
	}

	public void disconnect() {
		try {
			this.connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
			System.err.println("Unable to disconnect from " + mdbFile);
		}
	}
	
	public ArrayList<String> listAllLogs() {
		ArrayList<String> logs = new ArrayList<String>();
		String sql = "SELECT * FROM Registros INNER JOIN Mensagens ON" +
				" Registros.Mensagens_Code = Mensagens.Code ORDER BY Registros.ID;";
		try {
			Statement stmt = connection.createStatement();
			ResultSet resultSet = stmt.executeQuery(sql);
			
			while(resultSet.next()) {
				String mensagem = resultSet.getString("Message");
				String usuario = resultSet.getString("Usuarios_UserName");
				String data = String.valueOf(resultSet.getTimestamp("Data"));
				String arqName = resultSet.getString("ArqName");
				
				if(mensagem.contains("<login_name>")) {
					mensagem = mensagem.replace("<login_name>", usuario);
				}
				if(mensagem.contains("<arq_name>")) {
					mensagem = mensagem.replace("<arq_name>", arqName);
				}
				
				mensagem = data.substring(0, data.length()-2) + ": " + mensagem; 
				
				logs.add(mensagem);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.err.println("Unable to realize '" + sql + "' command");
		}

		return logs;
	}
	
}
